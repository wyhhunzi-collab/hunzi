# 成长 · 一程光阴

108 秒程序化三维情绪短片，1920×1080，30 FPS。没有真人素材和硬切镜头；采用同一组实体的连续空间重组，结合原上传音乐的实际瞬态时间戳驱动光路与字幕。

## 成片与交付

- `output/成长_1080p.mp4`：H.264 / AAC 成片（单独交付，源工程压缩包不重复收录）。
- `analysis/beats.json`：拍速估计、实际节拍、频段瞬态、能量变化、段落变化和转场锚点。
- `analysis/music_events.csv`：剪辑软件可读的事件时间表，同时保留原曲时间。
- `analysis/captions.srt`、`captions.json`：完整字幕与对应时间。
- `analysis/创作说明与时间表.md`：文案、时间段和每一幕的继承关系。
- `analysis/world_validation.json`：九处边界的几何 / 摄像机 / 光路连续性检查。
- `analysis/video_validation.json`：最终成片的帧数、解码、同步和画面变化检查（生成后提供）。
- `assets/source_music.mp3`：用户上传的原配乐。
- `assets/soundtrack.m4a`：实际用于成片的连续 108 秒裁切，含首尾渐变与响度处理。
- `preview/`：关键画面和预览。

## 运行环境

已在 Linux、Python 3.12、Mesa llvmpipe / EGL、FFmpeg 7.1.5 上实际执行。无需独立显卡。需要 OpenGL 3.3 或以上以及 FFmpeg 的 libx264、AAC 支持。项目不使用外部模型或网络图片。

```bash
cd growth
python -m pip install --target .vendor -r requirements.txt
./render.sh
```

若系统缺少 EGL / Mesa 和 FFmpeg，可通过系统软件包安装 `libegl1`、`libgl1-mesa-dri`、`ffmpeg`。中文字体子集及其许可证已收录，无需另行下载字体。

云任务已经处于独立环境中，直接使用当前检出目录，不需要创建 Git worktree。

## 预览与检查

```bash
python src/render.py --width 960 --height 540 --preview 4 15 25 36 47 59 70 82 93 102
python src/render.py --width 960 --height 540 --render --start 7 --duration 7 --output transition_preview.mp4
python src/validate_world.py
python src/validate_video.py output/成长_1080p.mp4
```

如依赖安装在 `.vendor`，运行分析和验证脚本时使用 `PYTHONPATH="$PWD/.vendor"`。渲染器会自行加载 `.vendor`。所有动画为确定性时间函数；可以从任意时间预览而不必先模拟前面的帧。

`render.sh` 会重建音频分析、字幕数据、完整三维影像和最终封装，然后完整解码检查。会覆盖 `output/` 中同名渲染结果；原始配乐不会修改。首次准备音频时，原 MP3 有一个损坏数据包被 FFmpeg 报告并跳过；最终采用从 0.429025 秒起的连续可解码部分，实际交付音频另行验证。

## 动画架构

- `src/world.py`：1050 个持久实体的十组空间状态；位置、尺寸、旋转、色彩与发光强度连续插值，转场轨迹附加平滑弧线。书桌、道路、楼体、车窗、手机、家门、时钟、镜子共用同一索引体系。
- `src/render.py`：真实三维透视、阴影贴图、四倍多重采样、景深近似、局部照明、灯光束近似、HDR 辉光与电影颗粒；每帧通过原始 RGB 管道交给 FFmpeg。
- `src/shaders.py`：材质光照、软化阴影、景深和色调映射的 GLSL。
- `src/assets.py`：原创建模贴图、中文文案与排版；没有使用参考视频的画面作为成片背景。
- `src/analyze_music.py`：STFT 谱通量、频段瞬态、自相关拍速与动态规划节拍追踪。
- `src/export_delivery.py`：字幕、事件表和视觉继承关系导出。

主光路由 180 个连续采样点构成，依次变为笔迹、道路中线、城市流光、车窗波纹、手机轮廓、台灯光圈、钟表圆周、镜面裂缝和向前道路。树木由 31 段递归分枝生长而成，保留到结尾。开场和片尾允许自然收黑，场景之间不采用整屏淡出淡入。

低 / 中 / 高频瞬态分别近似底鼓、军鼓与细碎鼓点；因为输入是混音，事件类型是频段推断，并非分离出的独立鼓轨。估计拍速约 113.46 BPM，但实际视觉脉冲依赖测得的非等间距事件。

音乐裁切起点是原曲 `0.4290249433106576` 秒。画面零点、字幕零点与裁切后的音频零点一致。首尾淡音和响度归一化不会改变速度。

## 美术与叙事

温暖的童年金色经由失落的红、独处的蓝、修复的青绿回到晨光。重点情绪停留在删掉的消息、家门里的暖灯和仍留着的旧车票。没有配音，字幕与音乐共同承担叙事。

渲染选择可执行的程序化风格三维画面。光束和景深采用实时近似；不依赖离线光线追踪或流体求解器。粒子运动为可重现的参数化运动与几何重组。
