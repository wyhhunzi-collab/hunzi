"""Headless OpenGL 3.3 cinematic renderer. Software EGL is supported.
Usage: python src/render.py --preview 5 15 25 36 47 59 70 82 93 102
       python src/render.py --render --width 1920 --height 1080 --fps 30
"""
import os
os.environ.setdefault('LP_NUM_THREADS','5')
os.environ.setdefault('MESA_SHADER_CACHE_DIR','/tmp/growth-mesa-cache')
os.environ.setdefault('OPENBLAS_NUM_THREADS','1')
import sys,time,json,argparse,subprocess
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'.vendor'))
import moderngl as gl
import numpy as np
from PIL import Image,ImageDraw
from world import *
from assets import make_assets,text_image,CAPTIONS,CHAPTERS,font
import shaders
AUDIO=json.loads((ROOT/'analysis/beats.json').read_text())
ANCHORS=AUDIO['scene_anchors']

def look_at(eye,target,up=np.array([0,1,0])):
 eye=np.array(eye,dtype=float);f=np.array(target,dtype=float)-eye;f/=np.linalg.norm(f);s=np.cross(f,up);s/=np.linalg.norm(s);u=np.cross(s,f)
 m=np.eye(4);m[0,:3]=s;m[1,:3]=u;m[2,:3]=-f;m[:3,3]=-m[:3,:3]@eye;return m

def perspective(fov,aspect,near=.08,far=150):
 a=1/np.tan(fov*np.pi/360);m=np.zeros((4,4));m[0,0]=a/aspect;m[1,1]=a;m[2,2]=(far+near)/(near-far);m[2,3]=2*far*near/(near-far);m[3,2]=-1;return m

def ortho(l,r,b,t,n,f):
 m=np.eye(4);m[0,0]=2/(r-l);m[1,1]=2/(t-b);m[2,2]=-2/(f-n);m[0,3]=-(r+l)/(r-l);m[1,3]=-(t+b)/(t-b);m[2,3]=-(f+n)/(f-n);return m

def write_mat(prog,name,m):
 if name in prog:prog[name].write(np.asarray(m,dtype='f4').T.tobytes())

def beveled_cube():
 verts=[]
 # Rounded corners give specular edge highlights even on small objects.
 coords=[-.5,-.445,.445,.5]
 for axis in range(3):
  others=[i for i in range(3) if i!=axis]
  for sign in [-1,1]:
   for a in range(3):
    for b in range(3):
     quad=[]
     for da,db in [(0,0),(1,0),(1,1),(0,1)]:
      p=np.zeros(3);p[axis]=sign*.5;p[others[0]]=coords[a+da];p[others[1]]=coords[b+db]
      q=np.clip(p,-.445,.445);n=p-q;n/=np.linalg.norm(n);p=q+n*.055;quad.append((p,n))
     # Culling disabled: winding is not used to discard a face.
     for idx in [0,1,2,0,2,3]:verts.extend([*quad[idx][0],*quad[idx][1]])
 return np.array(verts,'f4')

def sphere_mesh():
 v=[]
 def at(i,j):
  a=i/12*2*pi;b=j/8*pi;n=np.array([sin(b)*cos(a),cos(b),sin(b)*sin(a)]);return [*(n*.5),*n]
 for i in range(12):
  for j in range(8):
   for a,b in [(i,j),(i+1,j),(i+1,j+1),(i,j),(i+1,j+1),(i,j+1)]:v.extend(at(a,b))
 return np.array(v,'f4')

def mountain_mesh():
 verts=[]
 for i in range(8):
  a=i/8*2*pi;b=(i+1)/8*2*pi
  ps=[np.array([cos(a)*.5,-.5,sin(a)*.5]),np.array([cos(b)*.5,-.5,sin(b)*.5]),np.array([.06,.5,-.04])]
  normal=np.cross(ps[1]-ps[0],ps[2]-ps[0]);normal/=np.linalg.norm(normal)
  if normal[1]<0:normal=-normal
  for p in ps:verts.extend([*p,*normal])
 return np.array(verts,'f4')
def terrain(t,st):
 i,u,v=st
 w=(v if i==7 else 1 if i>=8 else 0)
 if w<.001:return np.empty((0,13),'f4')
 arr=[]
 for k in range(18):
  s=SEED[k+60];side=-1 if k%2 else 1;x=side*(9+s[0]*18);z=-9-s[1]*40;h=(3+s[2]*8)*w
  arr.append([x,h/2-.25,z,8+s[3]*11,h,8+s[4]*12,0,s[5]*2*pi,0,.045+s[6]*.06,.12+s[6]*.06,.13+s[6]*.02,0])
 return np.array(arr,'f4')

def seg(a,b,width,color,e=0):
 a=np.array(a);b=np.array(b);d=b-a;l=np.linalg.norm(d)
 return [*((a+b)*.5),width,l,width,np.arctan2(d[2],np.sqrt(d[0]**2+d[1]**2)),0,-np.arctan2(d[0],d[1]),*color,e]

def event_pulse(t,key,decay=.15):
 es=AUDIO[key];ts=np.array([e['time'] for e in es]);i=np.searchsorted(ts,t)-1
 if i<0:return 0
 return min(es[i]['strength'],1.5)*np.exp(-(t-ts[i])/decay)

def extras(t,st,accent):
 i,u,v=st
 cubes=[];spheres=[]
 # A single emissive thread physically retains its vertex identity through all ten worlds.
 p=get_ribbon(t,st);beat=event_pulse(t,'kick',.12)
 progress=np.clip((t-.5)/5,0,1) if i==0 else 1
 for j in range(len(p)-1):
  width=.018*(1+.3*beat)
  if j/len(p)>progress:width*=.015
  cubes.append(seg(p[j],p[j+1],width,accent,2.4))
 # A moving warm seed always accompanies the thread and becomes the final sun.
 seedidx=int((.5-.5*cos(t*.33))*(len(p)-1));seedpos=p[seedidx]
 spheres.append([*seedpos,.085,.085,.085,0,0,0,*accent,3])
 # Clock hands continue to move and divide into the mirror's growing cracks.
 cw=(1-v if i==6 else (v if i==5 else 0))
 if cw>0:
  for length,speed,offset,wd in [(1.8,.22,0,.06),(1.3,.08,1.1,.10)]:
   a=t*speed+offset;a0=[0,3,-.32];b=[sin(a)*length,3+cos(a)*length,-.32]
   cubes.append(seg(a0,b,wd*cw,GOLD,.8));spheres.append([0,3,-.31,.18*cw,.18*cw,.18*cw,0,0,0,*GOLD,.7])
 # The broken mirror's green line branches; this same tree moves beside the winding road.
 grow=smooth((t-79)/6)
 if grow>0:
  shift=np.zeros(3)
  if i==7:shift=mix(np.zeros(3),np.array([-5,0,-8]),v)
  elif i==8:shift=mix(np.array([-5,0,-8]),np.array([-9,0,-28]),v)
  elif i==9:shift=np.array([-9,0,-28])
  for n,(a,b,wd,lv) in enumerate(BRANCHES):
   g=smooth((grow-lv*.13)/.45)
   aa=a+shift;bb=mix(a,b,g)+shift
   if g>.001:
    cubes.append(seg(aa,bb,wd*min(1,g*2),TEAL*.65,.25))
    if lv>=3:
     for k in range(3):
      pos=bb+np.array([.14*sin(n*3+k),.06*k,.16*cos(n+k)])
      spheres.append([*pos,.32*g,.09*g,.14*g,0,.7*n,.3,*mix(TEAL,GOLD,.16),.12])
 # Human traces are understated silhouettes, never a live action dependency.
 def person(x,y,z,size,col):
  for off,dim in [((0,1.65,0),(.39,.43,.38)),((0,.99,0),(.58,.95,.32)),((-.19,.28,0),(.2,.65,.21)),((.19,.28,0),(.2,.65,.21)),((-.39,1.0,0),(.16,.76,.2)),((.39,1.,0),(.16,.76,.2))]:
   po=np.array([x,y,z])+np.array(off)*size;di=np.array(dim)*size
   spheres.append([*po,*di,0,0,0,*col,.02])
 weights=np.zeros(10);weights[i]=1-v;weights[min(i+1,9)]+=v
 if weights[2]>.001:
  for k in range(9):
   x=((k*1.7+t*.45)%15)-7.5;z=-3-(k%3)*4
   person(x,0,z,weights[2]*(.75+.08*(k%3)),(.022,.035,.05))
 if weights[3]>.001:person(-.7,.5,-1.58,weights[3]*1.25,(.022,.065,.10))
 if weights[7]>.001:person(.12,.7,-.36,weights[7]*1.65,(.045,.115,.12))
 if weights[1]>.001:
  for k in range(18):
   rr=SEED[k];po=[(rr[0]-.5)*24,5+rr[1]*4,-7-rr[2]*22];s=weights[1]
   spheres.append([*po,(2+rr[3]*2)*s,(.6+rr[4])*.7*s,(1.5+rr[3])*s,0,0,0,.31,.3,.25,0])
 # Home's lamp: light visibly has a source, not an arbitrary global flash.
 if weights[5]>.001:person(.7,0,-2.9,1.65*weights[5],(.11,.075,.036))
 if weights[5]>.001:spheres.append([3,2.91,-.3,.27,.27,.27,0,0,0,*GOLD,4*weights[5]])
 if cw>0:spheres.append([0,3,-.65,4.8*cw,4.8*cw,.18,0,0,0,.028,.045,.06,0])
 return np.array(cubes,'f4'),np.array(spheres,'f4')

class Renderer:
 def __init__(self,w=1920,h=1080):
  self.w=w;self.h=h;self.ctx=gl.create_standalone_context(backend='egl');c=self.ctx
  print('Renderer:',c.info['GL_RENDERER'],flush=True)
  self.prog=c.program(vertex_shader=shaders.VERT,fragment_shader=shaders.FRAG)
  self.depthprog=c.program(vertex_shader=shaders.VERT,fragment_shader=shaders.DEPTH_FRAG)
  self.meshes={};self.buf=c.buffer(reserve=16000*13*4)
  for name,data in [('cube',beveled_cube()),('sphere',sphere_mesh()),('mountain',mountain_mesh())]:
   vb=c.buffer(data.tobytes());self.meshes[name]=(vb,len(data)//6)
  self.vaos={}
  for name,(vb,n) in self.meshes.items():
   for p in [self.prog,self.depthprog]:
    fmt='3f 3f' if p==self.prog else '3f 12x'
    attrs=['in_vert','in_normal'] if p==self.prog else ['in_vert']
    instattrs=['i_pos','i_size','i_rot','i_color','i_emit'] if p==self.prog else ['i_pos','i_size','i_rot']
    instfmt='3f 3f 3f 3f 1f /i' if p==self.prog else '3f 3f 3f 16x /i'
    self.vaos[(name,p.glo)]=c.vertex_array(p,[(vb,fmt,*attrs),(self.buf,instfmt,*instattrs)])
  self.color=c.texture((w,h),4,dtype='f2');self.depth=c.depth_renderbuffer((w,h),samples=4);self.mscolor=c.renderbuffer((w,h),components=4,samples=4,dtype='f2');self.fbo=c.framebuffer([self.mscolor],self.depth);self.resolved_depth=c.depth_texture((w,h));self.resolved_depth.compare_func='';self.resolve=c.framebuffer([self.color],self.resolved_depth)
  self.outtex=c.texture((w,h),4);self.out=c.framebuffer([self.outtex])
  self.blurtex=[c.texture((w//4,h//4),4,dtype='f2') for _ in range(2)];self.blurfbo=[c.framebuffer([t]) for t in self.blurtex]
  for tx in [self.color,*self.blurtex]:tx.filter=(gl.LINEAR,gl.LINEAR);tx.repeat_x=False;tx.repeat_y=False
  self.softtex=[c.texture((w//4,h//4),4,dtype='f2') for _ in range(2)];self.softfbo=[c.framebuffer([tx]) for tx in self.softtex]
  for tx in self.softtex:tx.filter=(gl.LINEAR,gl.LINEAR);tx.repeat_x=False;tx.repeat_y=False
  self.shadow=c.depth_texture((1536,1536));self.shadow.compare_func='<=';self.shadow.repeat_x=False;self.shadow.repeat_y=False;self.shadowfbo=c.framebuffer(depth_attachment=self.shadow)
  self.lightvp=ortho(-21,21,-19,19,.1,80)@look_at([-13,27,15],[0,0,-5])
  qb=c.buffer(np.array([-1,-1,1,-1,-1,1,1,1],'f4').tobytes());self.quads={};self.ps={}
  for name,frag,vert in [('sky',shaders.SKY,shaders.QUAD),('blur',shaders.BLUR,shaders.QUAD),('post',shaders.POST,shaders.QUAD),('text',shaders.TEXT_FRAG,shaders.TEXT_VERT)]:
   p=c.program(vertex_shader=vert,fragment_shader=frag);self.ps[name]=p;self.quads[name]=c.vertex_array(p,[(qb,'2f','in_pos')])
  self.surface=c.program(vertex_shader=shaders.SURFACE_VERT,fragment_shader=shaders.SURFACE_FRAG)
  self.beam=c.program(vertex_shader=shaders.BEAM_VERT,fragment_shader=shaders.BEAM_FRAG);self.beambuf=c.buffer(reserve=300*5*4);self.beamvao=c.vertex_array(self.beam,[(self.beambuf,'3f 2f','in_vert','in_uv')])
  self.surfbuf=c.buffer(reserve=24*5*4);self.surfvao=c.vertex_array(self.surface,[(self.surfbuf,'3f 2f','in_vert','in_uv')])
  self.assets={k:self.texture(im) for k,im in make_assets().items()}
  self.captions=[]
  # Subtitles are short, high contrast and well inside mobile platform safe areas.
  for a,b,txt in CAPTIONS:self.captions.append((a,b,txt,self.texture(text_image(txt,46,serif=True))))
  self.chapters=[self.texture(text_image(f'{i+1:02d}   /   {txt}',22,color=(194,183,160,255))) for i,txt in enumerate(CHAPTERS)]
  self.top=self.texture(text_image('G R O W T H   /   一 程 光 阴',18,color=(158,155,143,255)))
  self.title=self.texture(text_image('成长',148,serif=True,pad=25));self.title_sub=self.texture(text_image('那些后来才听懂的话',27,color=(202,185,150,255),serif=True))
  self.endtitle=self.texture(text_image('原来，我已经走了这么远。',42,serif=True))
  self.endmark=self.texture(text_image('成长  /  仍有出发的勇气',23,color=(216,192,144,255)))
 def texture(self,im):
  im=im.convert('RGBA');tx=self.ctx.texture(im.size,4,im.tobytes());tx.filter=(gl.LINEAR,gl.LINEAR);tx.repeat_x=False;tx.repeat_y=False;return tx
 def draw(self,data,shape,p):
  if len(data)==0:return
  self.buf.write(np.asarray(data,'f4').tobytes());self.vaos[(shape,p.glo)].render(instances=len(data))
 def quad(self,name,**kwargs):
  p=self.ps[name]
  for k,val in kwargs.items():
   if k in p:p[k].value=val
  self.quads[name].render(gl.TRIANGLE_STRIP)
 def overlay(self,tx,x,y,opacity=1,scale=1,reveal=1.1,center=False):
  # Positions specified in the 1920x1080 design coordinate space.
  ww,hh=tx.size;ww*=scale;hh*=scale
  if center:x-=ww/2
  rect=(x/1920,1-(y+hh)/1080,ww/1920,hh/1080)
  tx.use(0);self.quad('text',image=0,rect=rect,opacity=float(opacity),reveal=float(reveal))
 def paper_points(self,t,st):
  i,u,v=st;j=min(i+1,9)
  uv=np.array([[.5,.5],[0,0],[.5,0],[1,0],[1,.5],[1,1],[.5,1],[0,1],[0,.5]],float)
  x=uv[:,0]*2-1;y=uv[:,1]*2-1
  def target(k):
   if k==0:
    p=np.stack([x*1.26-.55,np.ones(9)*1.73,y*.86+.25],1)
    f=smooth((u-.30)/.45) if i==0 else 0
    folded=np.stack([x*(.18+(y+1)*.46),3.2+.32*(1-abs(x))+.1*y,y*1.5+.2],1)
    return mix(p,folded,f)
   if k==1:
    p=np.stack([x*(.18+(y+1)*.46),3.25+.32*(1-abs(x))+.1*y,y*1.5+.2],1)
    p[:,0]+=.35*sin(t*.7);p[:,1]+=.16*sin(t*.8);return p
   if k==2:return np.stack([x*.9-1.3,3.5+y*.7,.4+np.abs(x)*.3],1)
   if k==3:return np.stack([x*4.25,2.6+y*1.92,np.ones(9)*-1.64],1)
   if k==4:return np.stack([x*1.20,2.45+y*2.23,np.ones(9)*.13],1)
   if k==5:return np.stack([2.4+x*.31,1.98+y*.32,.55-y*.1],1)
   if k==6:return np.stack([3.7+x*.73,2.2+y*.34,.25+y*.05],1)
   if k==7:return np.stack([x*1.95,3+y*2.4,np.ones(9)*-.40],1)
   if k==8:return np.stack([-4.6+x*.32*(1-y*y),5+y*.5,-8+np.abs(x)*.14],1)
   return np.stack([x*.005,5.8+y*.005,np.ones(9)*-24],1)
  a=target(i);b=target(j);p=mix(a,b,v);p[:,1]+=sin(v*pi)*.5
  if t<3.4:
   birth=smooth((t-.3)/3.1);origin=np.array([-1.7,3.6,-2.2]);p=mix(np.tile(origin,(9,1)),p,birth)
  verts=[]
  for k in range(1,9):
   for n in [0,k,1 if k==8 else k+1]:verts.extend([*p[n],*uv[n]])
  return np.array(verts,'f4')
 def render(self,t,read=True):
  c=self.ctx;data,eye,look,accent,st=frame_state(t,ANCHORS,event_pulse(t,'kick'));i,u,v=st;j=min(i+1,9)
  extra,spheres=extras(t,st,accent);cubes=np.concatenate([data,extra],0);mountains=terrain(t,st)
  vp=perspective(44,self.w/self.h)@look_at(eye,look)
  # Actual depth shadow pass; both life objects and dust occupy the same 3D space.
  c.enable(gl.DEPTH_TEST);c.disable(gl.BLEND);self.shadowfbo.use();c.viewport=(0,0,1536,1536);self.shadowfbo.clear(depth=1)
  write_mat(self.depthprog,'vp',self.lightvp);self.draw(cubes,'cube',self.depthprog);self.draw(spheres,'sphere',self.depthprog);self.draw(mountains,'mountain',self.depthprog)
  self.fbo.use();c.viewport=(0,0,self.w,self.h);self.fbo.clear(0,0,0,1,depth=1)
  c.disable(gl.DEPTH_TEST)
  # Sun exists at opening and returns at dawn, while middle acts keep intimate black levels.
  dawn=smooth((t-97)/7);sunpower=dawn*.33
  sun=np.array([.62,.58]);proj=vp@np.array([0,5.8,-25,1]);sun=proj[:2]/proj[3]*.5+.5
  self.quad('sky',accent=tuple(accent),sun=tuple(sun),sun_power=float(sunpower),sun_radius=float(.045+.025*smooth((t-97)/6)+.045*smooth((t-103)/4)),time=float(t))
  c.enable(gl.DEPTH_TEST)
  p=self.prog;write_mat(p,'vp',vp);write_mat(p,'light_vp',self.lightvp)
  p['camera'].value=tuple(eye);p['key_color'].value=tuple(mix(np.array([.65,.74,.91]),np.array([1.1,.73,.37]),float(accent[0])));p['accent'].value=tuple(accent)
  lightpos=mix(np.array([0,3,2]),np.array([3,2.9,-.3]),float((1-v if i==5 else v if i==4 else 0)))
  p['local_light'].value=tuple(lightpos);p['local_power'].value=float(1.1+event_pulse(t,'kick')*.12)
  self.shadow.use(4);p['shadowmap'].value=4
  self.draw(cubes,'cube',p);self.draw(spheres,'sphere',p);self.draw(mountains,'mountain',p)
  # A single deforming triangular surface: notebook > aircraft > mark > glass > phone > photo > ticket > mirror > leaf.
  c.enable(gl.BLEND);c.blend_func=gl.SRC_ALPHA,gl.ONE_MINUS_SRC_ALPHA
  self.surfbuf.write(self.paper_points(t,st).tobytes());sp=self.surface;write_mat(sp,'vp',vp)
  names=['notebook','blank','exam','window','phone','photo','ticket','mirror','leaf','gold'];op=[1,1,1,.11,1,1,1,.32,1,1]
  phone_name='phone_empty' if t<43.5 else ('phone_message' if t<48.2 else 'phone')
  names[4]=phone_name
  self.assets[names[i]].use(0);self.assets[names[j]].use(1);sp['texa'].value=0;sp['texb'].value=1;sp['blend_value'].value=float(v);sp['opacity'].value=float(mix(op[i],op[j],v));sp['tint'].value=(1.3,1.3,1.3)
  self.surfvao.render()
  c.disable(gl.DEPTH_TEST);c.disable(gl.BLEND)
  # Light shafts live in world space and are depth-tested against the objects.
  bw=float((1-v if i==0 else 0)*smooth((t-1)/2))
  hw=float((1-v if i==5 else v if i==4 else 0))
  beams=[]
  for typ,weight in [('window',bw),('lamp',hw)]:
   if weight<.001:continue
   count=4 if typ=='window' else 7
   for k in range(count):
    if typ=='window':
     a=np.array([-3.1+k*.83,5.4,-2.1]);b=a+np.array([3,-5.3,5.8]);width=.24;power=weight*.7
    else:
     aa=k/count*2*pi;a=np.array([3+.3*cos(aa),2.92,-.3+.3*sin(aa)]);b=np.array([3+1.4*cos(aa),1.62,-.3+1.4*sin(aa)]);width=.25;power=weight*.4
    off=np.array([width,0,0]);quad=[a-off,a+off,b+off*2,b-off*2];uvv=[[0,0],[1,0],[1,1],[0,1]]
    for z in [0,1,2,0,2,3]:beams.extend([*quad[z],*uvv[z]])
  if beams:
   c.enable(gl.DEPTH_TEST);c.enable(gl.BLEND);c.blend_func=gl.SRC_ALPHA,gl.ONE
   self.beambuf.write(np.array(beams,'f4').tobytes());write_mat(self.beam,'vp',vp);self.beam['color'].value=tuple(GOLD);self.beam['power'].value=float(max(bw,hw));self.beamvao.render(vertices=len(beams)//5)
   c.disable(gl.DEPTH_TEST);c.disable(gl.BLEND)
  c.copy_framebuffer(self.resolve,self.fbo)
  # Bloom is restricted to emitted light; it never substitutes for a transition.
  self.blurfbo[0].use();c.viewport=(0,0,self.w//4,self.h//4);self.color.use(0)
  self.quad('blur',source=0,step_uv=(1.2/self.w,0),threshold=.8)
  self.blurfbo[1].use();self.blurtex[0].use(0);self.quad('blur',source=0,step_uv=(0,5.0/self.h),threshold=0.)
  self.softfbo[0].use();self.color.use(0);self.quad('blur',source=0,step_uv=(5.0/self.w,0),threshold=0.)
  self.softfbo[1].use();self.softtex[0].use(0);self.quad('blur',source=0,step_uv=(0,5.0/self.h),threshold=0.)
  self.out.use();c.viewport=(0,0,self.w,self.h);self.color.use(0);self.blurtex[1].use(1);self.resolved_depth.use(2);self.softtex[1].use(3)
  fade=float(smooth(t/1.8)*(1-smooth((t-106.8)/1.2)))
  self.quad('post',source=0,bloom=1,depth_map=2,soft_scene=3,focus=float(np.linalg.norm(eye-look)),time=float(t),fade=fade)
  c.enable(gl.BLEND);c.blend_func=gl.SRC_ALPHA,gl.ONE_MINUS_SRC_ALPHA
  # Quiet editorial layer. Glyph reveals snap to measured midrange transients, with a soft edge.
  self.overlay(self.top,1380,93,opacity=.65*fade)
  self.overlay(self.chapters[i],100,93,opacity=.8*fade*(1-v))
  if v>.001:self.overlay(self.chapters[j],100,93,opacity=.8*fade*v)
  for a,b,txt,tx in self.captions:
   if a<=t<=b:
    opacity=smooth((t-a)/.32)*(1-smooth((t-(b-.32))/.32))*fade
    # A sentence builds in meaningful short groups on real transient peaks.
    ts=[e['time'] for e in AUDIO['snare'] if a<=e['time']<=a+1.1]
    count=sum(t>=x for x in ts);rev=max(min(1.1,.32+count*.25+smooth((t-a)/1.25)*.25),smooth((t-a)/1.4)*1.1)
    self.overlay(tx,960,893,opacity=float(opacity),center=True,reveal=rev)
  if 1<t<6.5:
   op=float(smooth((t-1)/1.1)*(1-smooth((t-5.5))))
   self.overlay(self.title,140,310,op,reveal=float(smooth((t-1)/1.7)*1.1));self.overlay(self.title_sub,158,512,op)
  if t>102.8:
   op=float(smooth((t-102.8)/1.5)*fade)
   self.overlay(self.endtitle,960,680,op,center=True);self.overlay(self.endmark,960,752,op*.8,center=True)
  c.disable(gl.BLEND)
  if read:
   raw=self.out.read(components=3,alignment=1)
   return np.frombuffer(raw,np.uint8).reshape(self.h,self.w,3)[::-1].copy()

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--preview',type=float,nargs='*');ap.add_argument('--render',action='store_true');ap.add_argument('--width',type=int,default=1920);ap.add_argument('--height',type=int,default=1080);ap.add_argument('--fps',type=int,default=30);ap.add_argument('--start',type=float,default=0);ap.add_argument('--duration',type=float,default=108);ap.add_argument('--output',default='growth_silent.mp4');args=ap.parse_args()
 r=Renderer(args.width,args.height)
 if args.preview is not None:
  for t in args.preview:
   a=time.time();im=r.render(t);path=ROOT/'preview'/f'frame_{t:06.2f}.jpg';Image.fromarray(im).save(path,quality=94);print(path.name,'%.3fs'%(time.time()-a),flush=True)
 if args.render:
  path=ROOT/'output'/args.output;n=int(args.duration*args.fps)
  cmd=['ffmpeg','-y','-v','warning','-f','rawvideo','-pix_fmt','rgb24','-s',f'{args.width}x{args.height}','-r',str(args.fps),'-i','pipe:0','-an','-c:v','libx264','-preset','fast','-crf','18','-pix_fmt','yuv420p','-threads','2','-movflags','+faststart',str(path)]
  proc=subprocess.Popen(cmd,stdin=subprocess.PIPE);a=time.time()
  try:
   for f in range(n):
    im=r.render(args.start+f/args.fps);proc.stdin.write(im.tobytes())
    if f%90==0:print(f'FRAME {f}/{n} | {f/args.fps:.1f}s | elapsed {time.time()-a:.1f}s | fps {(f+1)/(time.time()-a):.2f}',flush=True)
   proc.stdin.close();ret=proc.wait()
   if ret:raise RuntimeError(f'ffmpeg exit {ret}')
  except BaseException:
   proc.kill();raise
  print('COMPLETE',path,'elapsed',time.time()-a,flush=True)
if __name__=='__main__':main()
