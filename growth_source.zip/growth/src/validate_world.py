"""Meaningful mathematical checks for boundary continuity and valid geometry."""
from pathlib import Path
import json,numpy as np
from world import frame_state,get_ribbon,stage,STATES,BRANCHES
ROOT=Path(__file__).resolve().parents[1]
a=json.loads((ROOT/'analysis/beats.json').read_text())['scene_anchors']
report={'persistent_objects':int(STATES.shape[1]),'organic_branch_segments':len(BRANCHES),'boundary_checks':[]}
for t in a[1:-1]:
 l=frame_state(t-1e-5,a);r=frame_state(t+1e-5,a)
 delta=np.abs(l[0]-r[0]);eye=float(np.max(np.abs(l[1]-r[1])));look=float(np.max(np.abs(l[2]-r[2])))
 # Dust and offscreen city trails can wrap their periodic domains. The first 8 retained structural objects cannot.
 structural=float(delta[:8].max());ribbon=float(np.abs(get_ribbon(t-1e-5,l[4])-get_ribbon(t+1e-5,r[4])).max())
 assert structural<.01,(t,structural)
 assert eye<.001 and look<.001,(t,eye,look)
 assert ribbon<.001,(t,ribbon)
 report['boundary_checks'].append({'time':t,'structural_max_delta':structural,'camera_max_delta':max(eye,look),'thread_max_delta':ribbon})
for t in np.linspace(0,108,1081):
 d,e,l,c,s=frame_state(t,a)
 assert np.isfinite(d).all() and np.isfinite(e).all()
 assert (d[:,3:6]>0).all(),t
 assert (d[:,9:12]>=0).all(),t
report['continuous_frames_sampled']=1081;report['passed']=True
(ROOT/'analysis/world_validation.json').write_text(json.dumps(report,indent=2))
print(json.dumps(report,indent=2))
