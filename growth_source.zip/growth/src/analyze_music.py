from pathlib import Path
import sys,json
import numpy as np
from scipy.io import wavfile
from scipy import signal,ndimage
ROOT=Path(__file__).resolve().parents[1]
sr,y=wavfile.read(ROOT/'analysis/music.wav'); y=y.astype(np.float32)/32768
hop=220
_,tt,z=signal.stft(y,sr,nperseg=2048,noverlap=2048-hop,boundary='zeros')
m=np.abs(z); freq=np.fft.rfftfreq(2048,1/sr)
flux=np.maximum(np.diff(np.log1p(m*100),axis=1,prepend=np.zeros((m.shape[0],1))),0)
def envelope(lo,hi):
 a=flux[(freq>=lo)&(freq<hi)].mean(axis=0)
 a=ndimage.gaussian_filter1d(a,1)
 return a/max(np.quantile(a,.97),1e-6)
kick=envelope(35,180); snare=envelope(180,3500); hat=envelope(5000,10000)
onset=.55*kick+.3*snare+.15*hat
ac=signal.fftconvolve(onset-onset.mean(),(onset-onset.mean())[::-1],mode='full')[len(onset)-1:]
lo=int(sr/hop*60/160); hi=int(sr/hop*60/75)
peaks,_=signal.find_peaks(ac[lo:hi]); lags=peaks+lo
lag=lags[np.argmax(ac[lags])]; bpm=60*sr/hop/lag
# Dynamic programming: every beat is selected from measured onsets, not a uniform clock.
period=lag
local=ndimage.gaussian_filter1d(onset,1)
score=np.zeros(len(local)); back=np.full(len(local),-1,int)
for i in range(len(local)):
 js=np.arange(max(0,i-int(1.5*period)),max(0,i-int(.65*period)))
 if len(js):
  scores=score[js]-3*np.log((i-js)/period)**2
  j=js[np.argmax(scores)]
  score[i]=local[i]+max(0,scores.max()); back[i]=j
 else: score[i]=local[i]
i=np.argmax(score[-int(period*2):])+len(score)-int(period*2); beats=[]
while i>=0:
 beats.append(float(tt[i])); i=back[i]
beats=beats[::-1]
# Keep an actual opening phrase, followed by ~108 s of the supplied recording.
start=next((b for b in beats if b>=0.05),0)
duration=108.0
end=start+duration
out={'source_file':'TERACY、DJLeeny - Vibe知识大赏 (Claude).mp3','source_duration':len(y)/sr,'crop_start':start,'duration':duration,'sample_rate':sr,'analysis_hop_seconds':hop/sr,'estimated_bpm':float(bpm),'method':'STFT log spectral flux, separate bass/mid/high bands; tempo autocorrelation; dynamic-programming beat path; all visual impulses use measured transient timestamps.'}
for name,env,prom,dist in [('kick',kick,.16,.22),('snare',snare,.15,.20),('hihat',hat,.16,.10)]:
 ix,prop=signal.find_peaks(env,prominence=prom,distance=int(dist*sr/hop))
 out[name]=[{'time':round(float(tt[i]-start),4),'strength':round(float(env[i]),4),'source_time':round(float(tt[i]),4)} for i in ix if start<=tt[i]<end]
out['beats']=[round(b-start,4) for b in beats if start<=b<end]
# Phrase candidates from actual energy / timbre novelty; not fixed bar lengths.
rms=np.sqrt(ndimage.uniform_filter1d(y*y,int(sr*.25))[::hop])[:len(tt)]
if len(rms)<len(tt): rms=np.pad(rms,(0,len(tt)-len(rms)),mode='edge')
energy=ndimage.gaussian_filter1d(rms,80)
centroid=(m*freq[:,None]).sum(axis=0)/(m.sum(axis=0)+1e-8)
novelty=np.abs(np.gradient(energy))*20+np.abs(np.gradient(ndimage.gaussian_filter1d(centroid,60)))/1000
ix,_=signal.find_peaks(novelty,prominence=np.quantile(novelty,.7),distance=int(5*sr/hop))
out['phrase_changes']=[round(float(tt[i]-start),4) for i in ix if start+3<tt[i]<end-3]
out['energy']=[{'time':round(t-start,2),'rms':round(float(energy[i]),4)} for i,t in enumerate(tt) if i%100==0 and start<=t<end]
# Match narrative landmarks to nearby measured strong transients.
marks=[0,10.5,20.5,31,42,53,65,76,87,98,108]
strong=sorted(out['kick']+out['snare'],key=lambda e:e['time'])
anchors=[0.0]
for t in marks[1:-1]:
 candidates=[e for e in strong if abs(e['time']-t)<1]
 anchors.append(min(candidates,key=lambda e:abs(e['time']-t)-.1*min(e['strength'],2))['time'] if candidates else t)
anchors.append(duration); out['scene_anchors']=anchors
(ROOT/'analysis/beats.json').write_text(json.dumps(out,ensure_ascii=False,indent=2))
print(json.dumps({k:v for k,v in out.items() if k not in ['energy','beats','kick','snare','hihat']},ensure_ascii=False,indent=2))
print('Detected events:',{k:len(out[k]) for k in ['beats','kick','snare','hihat']})
