"""Original code-drawn texture assets and UTF-8 editorial typography."""
from PIL import Image,ImageDraw,ImageFont,ImageFilter
import numpy as np
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
SERIF=str(ROOT/'assets/fonts/NotoSerifSC-Regular.otf')
SANS=str(ROOT/'assets/fonts/NotoSansSC-Regular.otf')
BOLD=str(ROOT/'assets/fonts/NotoSansSC-Bold.otf')
def font(n,serif=False,bold=False):return ImageFont.truetype(SERIF if serif else (BOLD if bold else SANS),n,index=0)
def text_image(text,size=48,color=(239,229,208,255),serif=False,pad=18):
 f=font(size,serif);box=f.getbbox(text);w=box[2]+pad*2;h=size*2+pad*2
 im=Image.new('RGBA',(w,h));d=ImageDraw.Draw(im);d.text((pad+1,pad-box[1]+2),text,font=f,fill=(3,7,12,180),stroke_width=2,stroke_fill=(3,7,12,130));d.text((pad,pad-box[1]),text,font=f,fill=color)
 return im.crop((0,0,w,size+pad*2+9))
def make_assets():
 assets={}
 im=Image.new('RGB',(1200,800),(210,199,166));d=ImageDraw.Draw(im)
 for y in range(100,760,62):d.line((45,y,1150,y),fill=(144,164,158),width=2)
 d.line((600,15,600,785),fill=(109,102,78),width=3)
 d.text((70,25),'作 文  ·  我 的 梦 想',font=font(32),fill=(85,91,84))
 for j,txt in enumerate(['长大以后，我想去很远的地方。','坐上火车，看从没看过的风景。','妈妈说，先把作业写完。']):d.text((75,118+j*125),txt,font=font(29),fill=(74,77,74))
 d.text((900,65),'78',font=font(85,serif=True),fill=(162,53,36));d.line((925,170,1090,140),fill=(162,53,36),width=5)
 assets['notebook']=im
 exam=im.copy();ed=ImageDraw.Draw(exam);ed.text((830,255),'再试一次',font=font(52),fill=(166,49,33));ed.line((150,360,450,340),fill=(166,49,33),width=8);assets['exam']=exam
 im=Image.new('RGB',(600,1080),(19,33,43));d=ImageDraw.Draw(im)
 d.text((40,45),'22:47',font=font(30),fill=(194,210,212));d.text((250,140),'妈妈',font=font(39),fill=(231,228,213))
 d.line((20,215,580,215),fill=(53,70,76),width=2)
 d.text((190,300),'今天  22:46',font=font(21),fill=(120,139,143))
 d.rounded_rectangle((45,385,465,495),radius=25,fill=(229,219,181));d.text((77,408),'到家了吗？',font=font(43),fill=(47,60,57))
 d.rounded_rectangle((70,880,555,965),radius=16,fill=(37,53,61));d.text((96,901),'挺好的，别担心。',font=font(28),fill=(130,151,151))
 d.text((45,1007),'输入中…',font=font(22),fill=(113,131,134));assets['phone']=im
 im0=im.copy();d0=ImageDraw.Draw(im0);d0.rectangle((0,350,600,850),fill=(19,33,43));d0.rectangle((0,850,600,1080),fill=(19,33,43));assets['phone_empty']=im0
 im1=im.copy();d1=ImageDraw.Draw(im1);d1.rectangle((0,850,600,1080),fill=(19,33,43));assets['phone_message']=im1
 # Small framed photograph: an original drawn memory, not an external stock image.
 im=Image.new('RGB',(700,800),(191,158,101));d=ImageDraw.Draw(im)
 d.rectangle((50,45,650,720),fill=(91,74,52));d.rectangle((180,80,555,630),fill=(221,182,105));d.rectangle((230,115,510,630),fill=(126,101,61))
 for x,y,s in [(300,420,1),(420,400,1.1),(365,520,.65)]:
  d.ellipse((x-27*s,y-80*s,x+27*s,y-26*s),fill=(57,55,45));d.rounded_rectangle((x-42*s,y-30*s,x+42*s,y+105*s),radius=25,fill=(57,55,45))
 d.text((140,735),'二〇〇六 · 夏天',font=font(27),fill=(74,63,47));assets['photo']=im
 im=Image.new('RGB',(1000,500),(202,192,160));d=ImageDraw.Draw(im)
 d.text((45,30),'单程 · 出发',font=font(35),fill=(78,85,75));d.text((55,130),'故 乡    →    远 方',font=font(64,serif=True),fill=(56,67,64));d.text((55,270),'第一次，一个人坐这么久的车。',font=font(28),fill=(100,106,94))
 for j in range(90):d.line((50+j*10,365,50+j*10,430),fill=(45,56,52),width=1+(j%3))
 assets['ticket']=im
 for name,col in [('blank',(222,215,188)),('red',(146,45,33)),('window',(17,39,61)),('mirror',(33,71,75)),('leaf',(51,122,88)),('gold',(241,181,73))]:assets[name]=Image.new('RGB',(16,16),col)
 for k,im in assets.items():im.save(ROOT/'assets'/f'{k}.png')
 return assets

# Each line stays short and tied to a concrete lived moment.
CAPTIONS=[
 (1.9,6.2,'小时候，最怕听见「回家了」。'),
 (6.6,10.1,'总觉得，长大就能走得更远。'),
 (12.1,16.3,'把愿望折成纸飞机。'),
 (16.8,20.3,'以为远方，什么都有。'),
 (22.0,26.3,'试卷写满，答案却不总如愿。'),
 (26.8,30.9,'第一次懂得，努力也会落空。'),
 (32.5,37.0,'第一次离家，行李很重。'),
 (37.4,41.8,'后来才懂，没人分担的更重。'),
 (43.8,47.6,'打了很久的字，又一个个删掉。'),
 (48.2,52.6,'最后只回了句：「挺好的。」'),
 (54.6,59.0,'从前嫌「早点回来」太啰嗦。'),
 (59.5,64.6,'后来，最想听见的也是这一句。'),
 (66.5,70.4,'旧车票还在，有些人走散了。'),
 (71.0,75.5,'没说出口的话，留在了那一年。'),
 (77.2,81.1,'也曾怪自己，怎么总不够好。'),
 (81.6,86.5,'现在，想先抱抱那个撑住的自己。'),
 (88.5,92.4,'不再拿别人的钟，催自己赶路。'),
 (93.0,97.5,'走慢一点，也是在往前。'),
 (99.2,102.7,'回头才发现，已经走了这么远。'),
 (103.0,107.4,'愿你长大以后，仍愿意出发。')]
CHAPTERS=['童年','远方','落差','独自','没事','回家','告别','和解','自己的速度','成长']
