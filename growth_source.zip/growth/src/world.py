"""Deterministic, continuous 3D world. Coordinates use Y up. No scene cuts."""
import numpy as np
from math import sin,cos,pi
N=1050
GOLD=np.array([1.,.55,.16]); BLUE=np.array([.065,.22,.48]); TEAL=np.array([.12,.68,.48]); RED=np.array([.8,.09,.055]); IVORY=np.array([.83,.76,.58])
rng=np.random.default_rng(1025)
SEED=rng.random((N,8))
def smooth(x):
 x=np.clip(x,0,1); return x*x*x*(x*(x*6-15)+10)
def mix(a,b,t): return a*(1-t)+b*t
class Set:
 def __init__(self,color):
  self.p=np.zeros((N,3)); self.s=np.full((N,3),.015); self.r=np.zeros((N,3)); self.c=np.tile(color,(N,1)); self.e=np.ones(N)*.4; self.i=0
  a=SEED[:,0]*2*pi; rad=7+SEED[:,1]*11
  self.p[:]=np.stack([np.cos(a)*rad,SEED[:,2]*9-1,np.sin(a)*rad-9],1)
 def box(self,p,s,c,r=(0,0,0),e=0):
  i=self.i; self.p[i]=p; self.s[i]=s; self.c[i]=c; self.r[i]=r; self.e[i]=e; self.i+=1; return i
 def line(self,a,b,width,c,e=0):
  a=np.array(a); b=np.array(b); d=b-a; l=np.linalg.norm(d)
  return self.box((a+b)/2,(width,l,width),c,(np.arctan2(d[2],np.sqrt(d[0]**2+d[1]**2)),0,-np.arctan2(d[0],d[1])),e)
 def data(self):return np.concatenate([self.p,self.s,self.r,self.c,self.e[:,None]],1).astype('f4')

def desk():
 w=Set(GOLD)
 w.box((0,1.5,0),(6,.22,3.5),(.28,.13,.055))
 for x in [-2.6,2.6]:
  for z in [-1.3,1.3]: w.box((x,.62,z),(.15,1.65,.15),(.16,.075,.03))
 w.box((0,-.28,-1),(15,.25,12),(.17,.14,.105))
 w.box((-3.5,3.6,-2.2),(.13,4.2,.17),IVORY)
 w.box((.1,3.6,-2.2),(.13,4.2,.17),IVORY)
 for y in [1.5,3.6,5.7]:w.box((-1.7,y,-2.2),(3.7,.12,.17),IVORY)
 w.box((-1.7,3.6,-2.2),(.09,4.2,.2),IVORY)
 # Open notebook with real page edges, binding, a pencil, eraser and book stack.
 w.box((-.55,1.66,.25),(2.75,.08,1.9),(.81,.74,.58),r=(0,.05,0))
 for j in range(7): w.box((-.55,1.64+j*.006,.25),(2.78,.006,1.92),(.69+.025*j,.65+.02*j,.53+.02*j))
 w.box((-.55,1.712,.25),(.025,.01,1.85),(.34,.27,.14))
 w.box((1.5,1.76,.15),(.10,.11,2.1),GOLD,r=(0,.65,0))
 w.box((2.1,1.78,.97),(.11,.11,.22),(.15,.13,.11),r=(0,.65,0))
 w.box((-.8,1.78,1.23),(.5,.13,.24),(.7,.32,.22),r=(0,-.2,0))
 for j in range(3):w.box((-2.1,1.78+j*.16,-.55),(1.05,.14,.8),[(.13,.23,.25),(.52,.25,.13),(.46,.4,.25)][j],r=(0,.08*j,0))
 # floorboards continue as the road's physical slats in the next state
 for j in range(50):w.box((-7.2+j*.29,-.12,-1),(.009,.01,12),(.055,.037,.023))
 for i in range(w.i,N):
  u=SEED[i]; w.p[i]=[-3+u[0]*6,1.4+u[1]*4,-2+u[2]*5]; w.s[i]=.009+u[3]*.012;w.e[i]=1.8; w.c[i]=GOLD*(.6+u[4]*.4)
 return w

def dream():
 w=Set(GOLD)
 # Same tabletop stretches into the road, same legs become elevated supports.
 w.box((0,-.02,-6),(3.6,.25,30),(.35,.25,.12))
 for x in [-1.6,1.6]:
  for z in [-3,-12]:w.box((x,-2,z),(.17,4,.17),(.4,.25,.1))
 w.box((0,-3.2,-9),(44,.2,50),(.07,.095,.11))
 for z in np.linspace(5,-22,30):w.box((0,.13,z),(.045,.02,.45),GOLD,e=1.7)
 # floating aspirational city: ivory, small windows, sculpted rooftops
 for row in range(5):
  for side in [-1,1]:
   for col in range(4):
    u=SEED[w.i]; x=side*(3+col*1.8); z=2-row*4.7; h=1+u[2]*6
    w.box((x,h/2-1,z),(1.1,h,1.3),IVORY*(.45+u[1]*.4))
    w.box((x,h-.9,z),(.8,.14,.9),GOLD*.5)
    for k in range(int(h*2)):
     w.box((x-.3+(k%2)*.55,k*.43-.2,z+.66),(.16,.16,.03),GOLD,e=1.6)
 for i in range(w.i,N):
  u=SEED[i];w.p[i]=[(u[0]-.5)*30,2+u[1]*11,-u[2]*32];w.s[i]=[.02,.02,.02];w.c[i]=GOLD;w.e[i]=1.8
 return w

def city():
 w=Set(RED)
 w.box((0,-.1,-6),(5,.22,37),(.025,.04,.065))
 for x in [-2.45,2.45]:
  for z in [-3,-12]:w.box((x,.02,z),(.45,.2,15),(.095,.12,.14))
 w.box((0,-.24,-6),(45,.15,50),(.015,.025,.045))
 for z in np.linspace(6,-22,22):w.box((0,.025,z),(.1,.02,.65),(.58,.48,.31),e=.4)
 for row in range(6):
  for side in [-1,1]:
   for col in range(2):
    u=SEED[w.i]; x=side*(3.7+col*3.1);z=3-row*5.2;h=4+u[2]*10
    w.box((x,h/2,z),(2.5,h,3.5),(.025,.055,.095))
    for yy in np.arange(.7,h,.85):
     for xx in [-.75,0,.75]:
      light=GOLD if SEED[w.i,3]>.25 else BLUE
      w.box((x+xx,yy,z+1.76),(.28,.38,.035),light*.6,e=.8 if SEED[w.i,4]>.3 else .1)
 # traffic signal, rain and red reflections; identity passes into train bars
 w.box((1.9,2.4,1),(.09,4.8,.09),(.08,.1,.13))
 w.box((1.9,4.35,1),(.42,.92,.34),(.035,.04,.05))
 for yy,co in [(4.62,RED),(4.35,(.16,.08,.01)),(4.08,(.01,.07,.05))]:w.box((1.9,yy,1.2),(.24,.24,.045),co,e=3 if yy>4.5 else 0)
 for i in range(w.i,N):
  u=SEED[i];w.p[i]=[(u[0]-.5)*20,u[1]*12,-u[2]*25];w.s[i]=[.012,.15+u[3]*.22,.012];w.c[i]=BLUE;w.e[i]=.7
 return w

def train():
 w=Set(BLUE)
 w.box((0,-.08,-1),(13,.24,6),(.045,.065,.09))
 # window around the lonely silhouette, centered off-axis
 for x in [-4.5,4.5]:w.box((x,2.5,-1.8),(.3,5,.3),(.13,.19,.24))
 for y in [.45,4.7]:w.box((0,y,-1.8),(9,.22,.3),(.13,.19,.24))
 w.box((0,5.1,0),(13,.22,6),(.04,.07,.1))
 w.box((0,.6,-1.9),(8.7,.12,.4),(.27,.33,.34))
 for x in [-5.4,5.4]:
  w.box((x,2.6,.5),(.08,4.7,.08),(.55,.59,.56))
  w.box((x,4.6,.5),(.8,.045,.06),(.6,.64,.61))
 for x in [-3,-1.5,0,1.5,3]:
  w.box((x,.5,1.5),(1.42,.24,1.1),(.055,.19,.24))
  w.box((x,1.12,2),(1.42,1.05,.17),(.045,.15,.19))
 # city lamps outside the window preserve city window identities
 for i in range(w.i,N):
  u=SEED[i];w.p[i]=[(u[0]-.5)*45,.5+u[1]*8,-3-u[2]*20];w.s[i]=[.1+u[3]*.2,.035,.035];w.c[i]=GOLD if u[4]>.68 else BLUE;w.e[i]=1+u[5]
 return w

def phone():
 w=Set(BLUE)
 # Tabletop inherited from train floor, blue window bars fold into a phone frame.
 w.box((0,-.5,0),(150,.25,150),(.025,.04,.06))
 for x in [-1.28,1.28]:w.box((x,2.45,0),(.12,4.72,.22),(.18,.24,.28))
 for y in [.1,4.8]:w.box((0,y,0),(2.65,.12,.22),(.2,.25,.28))
 w.box((0,2.45,-.1),(2.55,4.7,.14),(.025,.04,.055))
 w.box((0,4.58,.07),(.55,.07,.04),(.012,.02,.025))
 w.box((1.37,3.4,0),(.065,.5,.09),(.26,.3,.32))
 for i in range(w.i,N):
  u=SEED[i];a=u[0]*2*pi;r=4+u[1]*9;w.p[i]=[cos(a)*r,1+u[2]*6,sin(a)*r-3];w.s[i]=(.008+u[3]*.009)*(.18 if i%4 else 1);w.c[i]=mix(BLUE,GOLD,u[4]);w.e[i]=.8
 return w

def home():
 w=Set(GOLD)
 w.box((0,-.15,0),(13,.2,10),(.19,.105,.045))
 # Parent phone frame opens into a full size doorway.
 for x in [-1.85,1.85]:w.box((x,2.8,-1.5),(.22,5.7,.4),(.38,.19,.075))
 for y in [0,5.6]:w.box((0,y,-1.5),(3.9,.2,.4),(.46,.25,.09))
 w.box((-.9,2.7,-.15),(3.6,5.35,.16),(.34,.22,.1),r=(0,-1.1,0))
 # warm interior beyond the open frame
 w.box((0,2.6,-4),(10,5.5,.25),(.32,.21,.105))
 w.box((-3,1.2,-1.6),(2.4,2.4,1),(.22,.12,.05))
 for yy in [.6,1.4,2.2]:w.box((-3,yy,-1.06),(2.2,.025,.02),(.09,.055,.025))
 w.box((3,1.5,0),(2.6,.15,2),(.28,.14,.055))
 for xx in [2,4]:w.box((xx,.6,0),(.12,1.8,.12),(.16,.085,.03))
 # brass table lamp, photograph, two pairs of slippers
 w.box((3,1.65,-.3),(.8,.1,.6),(.35,.22,.08))
 w.box((3,2.55,-.3),(.06,1.8,.06),(.6,.39,.14))
 for j in range(12):
  a=j*2*pi/12;w.box((3+.45*cos(a),3.1,-.3+.45*sin(a)),(.3,.65,.05),(.9,.62,.24),r=(0,-a,0),e=.3)
 w.box((2.4,1.95,.5),(.7,.75,.06),(.45,.25,.09),r=(.12,0,.1))
 for xx in [-.65,-.3,.35,.7]:w.box((xx,.025,.3),(.25,.06,.65),(.5,.25,.09),r=(0,.1,0))
 for j in range(65):w.box((-6+j*.18,-.035,0),(.007,.012,10),(.09,.045,.018))
 for i in range(w.i,N):
  u=SEED[i];w.p[i]=[(u[0]-.5)*11,.4+u[1]*6,(u[2]-.5)*7];w.s[i]=(.009+u[3]*.016)*(.2 if i%3 else 1);w.c[i]=GOLD;w.e[i]=1.1
 return w

def clock():
 w=Set(GOLD)
 w.box((0,-.25,0),(150,.2,150),(.045,.065,.09))
 # The rectangular door jambs bend into the faceted brass clock's rim.
 for j in range(72):
  a=j/72*2*pi;w.box((cos(a)*2.5,3+sin(a)*2.5,-.6),(.22,.24,.28),GOLD*.4,r=(0,0,a),e=.15)
 for j in range(60):
  a=j/60*2*pi;w.box((cos(a)*2.16,3+sin(a)*2.16,-.42),(.045,.26 if j%5==0 else .12,.05),IVORY,r=(0,0,a-pi/2),e=.3)
 w.box((0,3,-.68),(.001,.001,.001),(.035,.055,.075))
 # Memories: photograph border, train ticket, empty chair, an unwritten letter.
 for x in [-4.1,-2.6]:w.box((x,1.8,0),(.06,1.3,.06),IVORY)
 for yy in [1.15,2.45]:w.box((-3.35,yy,0),(1.56,.06,.06),IVORY)
 w.box((-3.35,1.8,-.03),(1.45,1.2,.03),(.2,.24,.24))
 w.box((3.7,2.2,.2),(1.6,.8,.04),(.66,.57,.39),r=(0,.1,.18))
 # recognisable vacant chair
 w.box((2.8,.8,1),(1.3,.13,1.3),(.25,.15,.07))
 for x in [2.25,3.35]:
  for z in [.5,1.5]:w.box((x,.32,z),(.09,.85,.09),(.18,.1,.05))
 w.box((2.8,1.7,1.6),(1.3,1.6,.1),(.25,.14,.06))
 for i in range(w.i,N):
  u=SEED[i];a=u[0]*pi*2;rad=3.4+u[1]*5;w.p[i]=[cos(a)*rad,3+sin(a)*rad,-3-u[2]*8];w.s[i]=[.015,.015,.015];w.c[i]=mix(GOLD,BLUE,u[4]);w.e[i]=.7
 return w

def mirror():
 w=Set(TEAL)
 w.box((0,-.2,0),(150,.2,150),(.035,.095,.105))
 # Clock fragments settle into the mirror; existing identities are retained.
 for j in range(72):
  a=j/72*2*pi; x=2.15*np.sign(cos(a))*abs(cos(a))**.45; yy=3+2.8*np.sign(sin(a))*abs(sin(a))**.45
  b=(j+1)/72*2*pi;xx=2.15*np.sign(cos(b))*abs(cos(b))**.45;yyy=3+2.8*np.sign(sin(b))*abs(sin(b))**.45
  w.line((x,yy,-.5),(xx,yyy,-.5),.14,(.16,.35,.33),e=.15)
 for iy in range(10):
  for ix in range(8):
   x=(ix-3.5)*.49;y=.7+iy*.48;u=SEED[w.i]
   w.box((x,y,-.55+u[2]*.04),(.47,.46,.06),(.12+.05*u[0],.24+.05*u[0],.26+.07*u[0]),r=(u[1]*.015,u[2]*.025,u[3]*.015))
 # Moss and fragments begin to grow out of the ground, later become a tree.
 for i in range(w.i,N):
  u=SEED[i];w.p[i]=[(u[0]-.5)*13,-.03+u[1]*.13,(u[2]-.5)*10];w.s[i]=[.04+u[3]*.08,.025,.05];w.c[i]=mix(BLUE,TEAL,u[4]);w.e[i]=.4
 return w

# Precomputed organic branches, reused as the upward path in scene 9.
BRANCHES=[]
def branch(a,d,length,width,level,seed):
 rr=np.random.default_rng(seed);a=np.array(a);d=np.array(d);d=d/np.linalg.norm(d);b=a+d*length
 BRANCHES.append((a,b,width,level))
 if level<4:
  for j in [-1,1]:
   nd=d*.6+np.array([j*(.4+rr.random()*.4),.5,(rr.random()-.5)*.9]);branch(b,nd,length*.66,width*.67,level+1,seed*3+(j+2))
branch([0,0,0],[.08,1,0],2.2,.17,0,7)
def ascent():
 w=Set(TEAL)
 # The mirror plane becomes an elevated winding trail rather than disappearing.
 w.box((0,-.26,-4),(150,.3,150),(.035,.09,.1))
 for j in range(120):
  u=j/119;z=5-u*30;x=sin(u*pi*2)*2.3;y=u*5
  w.box((x,y-.12,z),(2.2,.17,.27),(.12+.1*u,.24+.1*u,.23),r=(0,-.4*cos(u*pi*2),0))
 for a,b,wd,lv in BRANCHES:
  w.line(a+[-5,0,-8],b+[-5,0,-8],wd,TEAL*.45)
 for i in range(w.i,N):
  u=SEED[i];a=u[0]*pi*2;r=7+u[1]*17;w.p[i]=[cos(a)*r,-.1+u[2]*.2,sin(a)*r-12];w.s[i]=[.012,.045+u[4]*.08,.012];w.p[i,1]=.1+u[2]*2.;w.c[i]=mix(TEAL*.5,GOLD*.3,u[6]);w.e[i]=.5
 return w

def dawn():
 w=Set(GOLD)
 w.box((0,-.2,-6),(180,.3,180),(.14,.14,.1))
 for j in range(120):
  u=j/119;z=7-u*42;x=sin(u*pi*1.5)*1.2;y=u*.35
  w.box((x,y,z),(2.25,.12,.38),(.42,.32,.16),r=(0,-.12*cos(u*pi*1.5),0))
 for i in range(w.i,N):
  u=SEED[i];a=u[0]*2*pi;r=1.5+u[1]*5;w.p[i]=[cos(a)*r,5.8+sin(a)*r,-24-u[2]*4];w.s[i]=[.03,.03,.03];w.c[i]=[GOLD,RED,BLUE,TEAL][i%4];w.e[i]=1.5
 return w

SETS=[desk(),dream(),city(),train(),phone(),home(),clock(),mirror(),ascent(),dawn()]
STATES=np.stack([w.data() for w in SETS])
# Viewing positions are smoothly interpolated across every narrative boundary.
EYES=np.array([[8,6.2,10],[0,4.6,11],[0,2.8,10],[5.3,3.3,8],[2.4,3.1,8.8],[8,5.8,10],[6,4,11],[5.8,4.1,10],[5.6,5.3,10],[1,3.3,0]],dtype=float)
LOOK=np.array([[0,2,0],[0,1,-6],[0,3,-7],[0,2.4,-1],[0,2.45,0],[0,2,-1],[0,2.7,-.4],[0,2.8,-.3],[0,2,-6],[0,4,-18]],dtype=float)
PALETTES=np.array([GOLD,GOLD,RED,BLUE,BLUE,GOLD,GOLD,TEAL,TEAL,GOLD])

def stage(t,anchors):
 # Hold a state, then physically reorganise its geometry over a generous 3.2 seconds.
 i=np.searchsorted(anchors,t,side='right')-1;i=int(np.clip(i,0,9));d=anchors[i+1]-anchors[i];u=(t-anchors[i])/d
 # Morph before the next landmark; never a full-frame fade between scenes.
 v=smooth((u-.67)/.33) if i<9 else 0
 return i,u,v

def frame_state(t,anchors,kick=0):
 i,u,v=stage(t,anchors);j=min(i+1,9)
 data=mix(STATES[i],STATES[j],v).copy()
 # Curling trajectories are zero at both ends; all the same blocks survive the transformation.
 arc=sin(v*pi)
 data[:,0]+=arc*np.sin(SEED[:,0]*pi*2)*(.25+SEED[:,1])
 data[:,1]+=arc*(.3+SEED[:,2]*1.5)
 data[:,2]+=arc*np.cos(SEED[:,0]*pi*2)*.35
 # Drift dust, rain, outside city trails; architecture stays anchored.
 for k,weight in [(i,1-v),(j,v)]:
  first=SETS[k].i
  ids=np.arange(first,N);s=SEED[first:]
  if k==2:
   data[ids,1]+=weight*((s[:,1]*12-t*4)%12-s[:,1]*12)
  elif k==3:
   data[ids,0]+=weight*((s[:,0]*45+t*12)%45-s[:,0]*45)
  elif k in [0,1,4,5,6,9]:
   data[ids,1]+=weight*np.sin(t*.5+s[:,0]*20)*.12
   data[ids,0]+=weight*np.sin(t*.22+s[:,1]*20)*.16
 # Inner pulse changes emissive energy and the light thread, not the whole screen.
 data[:,12]*=1+.15*kick
 hw=(1-v if i==5 else v if i==4 else 0)
 if hw>0:
  opening=smooth((t-53)/5)
  data[5,:3]+=np.array([.9,0,-1.6])*(1-opening)*hw
  data[5,7]+=.92*(1-opening)*hw
 if i==9:
  gathering=smooth((t-102.7)/4.0)
  ids=np.arange(SETS[9].i,N);ss=SEED[ids]
  dest=np.stack([np.sin(ss[:,0]*30)*.09,5.8-ss[:,1]*4,-24+ss[:,1]*30],1)
  data[ids,:3]=mix(data[ids,:3],dest,gathering)
  data[ids,9:12]=mix(data[ids,9:12],np.tile(GOLD,(len(ids),1)),gathering)
  data[ids,12]*=1+gathering*.8
 if t<3.4:
  birth=smooth((t-.3)/3.1)
  origin=np.array([-1.7,3.6,-2.2])
  data[:,:3]=mix(origin[None,:]+(SEED[:,:3]-.5)*.03,data[:,:3],birth)
  data[:,3:6]=mix(np.ones((N,3))*.003,data[:,3:6],birth)
  data[:,9:12]=mix(np.tile(GOLD,(N,1)),data[:,9:12],birth)
 eye=mix(EYES[i],EYES[j],smooth(u));look=mix(LOOK[i],LOOK[j],smooth(u))
 # purposeful slow orbit / push within each scene, with no reset discontinuity
 eye+=np.array([.55*sin(t*.115),.18*sin(t*.17),-.45*sin(t*.09)])
 return data,eye,look,mix(PALETTES[i],PALETTES[j],v),(i,u,v)

def ribbon_target(k,n=180):
 u=np.linspace(0,1,n);p=np.zeros((n,3))
 if k==0:p[:]=np.stack([-1.7+u*3,np.ones(n)*1.79,.5+.25*np.sin(u*5)],1)
 elif k==1:p[:]=np.stack([np.sin(u*7)*.6,.25+u*.15,6-u*31],1)
 elif k==2:p[:]=np.stack([.1+np.sin(u*10)*.2,np.ones(n)*.08,6-u*30],1)
 elif k==3:p[:]=np.stack([-4+u*8,2.8+np.sin(u*7)*.35,np.ones(n)*-1.6],1)
 elif k==4:
  a=u*2*pi;p[:]=np.stack([1.12*np.sign(np.cos(a))*abs(np.cos(a))**.35,2.45+2.18*np.sign(np.sin(a))*abs(np.sin(a))**.35,np.ones(n)*.14],1)
 elif k==5:
  a=u*3*pi;p[:]=np.stack([3+np.cos(a)*(.3+u*1.5),3.1+u*.5,-.3+np.sin(a)*(.3+u*1.5)],1)
 elif k==6:
  a=u*2*pi;p[:]=np.stack([np.cos(a)*2.5,3+np.sin(a)*2.5,np.ones(n)*-.39],1)
 elif k==7:p[:]=np.stack([.3*np.sin(u*17)+.6*np.sin(u*6),.3+u*5.3,np.ones(n)*-.41],1)
 elif k==8:p[:]=np.stack([np.sin(u*2*pi)*2.3,u*5+.12,5-u*30],1)
 elif k==9:p[:]=np.stack([np.sin(u*pi*1.5)*1.2,.2+u*.35,7-u*42],1)
 return p
RIBBONS=np.stack([ribbon_target(i) for i in range(10)])

def get_ribbon(t,st):
 i,u,v=st;j=min(i+1,9);p=mix(RIBBONS[i],RIBBONS[j],v).copy();q=np.linspace(0,1,len(p))
 p[:,1]+=sin(v*pi)*np.sin(q*pi)*1.4
 if t<3.4:p=mix(np.tile(np.array([-1.7,3.6,-2.2]),(len(p),1)),p,smooth((t-.3)/3.1))
 return p
