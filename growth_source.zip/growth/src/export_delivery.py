"""Export the human-readable music / text / continuity artifacts."""
from pathlib import Path
import json,csv,sys
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'src'))
from assets import CAPTIONS,CHAPTERS
music=json.loads((ROOT/'analysis/beats.json').read_text())
subs=[]
def clock(t,sep=','):
 ms=round(t*1000);h,ms=divmod(ms,3600000);m,ms=divmod(ms,60000);s,ms=divmod(ms,1000);return f'{h:02d}:{m:02d}:{s:02d}{sep}{ms:03d}'
for k,(a,b,text) in enumerate(CAPTIONS,1):subs.append(f'{k}\n{clock(a)} --> {clock(b)}\n{text}\n')
(ROOT/'analysis/captions.srt').write_text('\n'.join(subs))
(ROOT/'analysis/captions.json').write_text(json.dumps([{'start':a,'end':b,'text':t} for a,b,t in CAPTIONS],ensure_ascii=False,indent=2))
with (ROOT/'analysis/music_events.csv').open('w') as f:
 w=csv.writer(f);w.writerow(['film_time_seconds','source_time_seconds','event','strength'])
 for e in sorted([{'time':t,'source_time':t+music['crop_start'],'strength':'','event':'beat'} for t in music['beats']]+[dict(e,event=k) for k in ['kick','snare','hihat'] for e in music[k]],key=lambda e:e['time']):w.writerow([e['time'],round(e['source_time'],5),e['event'],e['strength']])
lines=['# 《成长》文案与视觉继承\n','成片时长：108 秒。字幕无配音，音乐为用户上传曲目的连续裁切。\n','## 完整文案\n','| 开始 | 结束 | 字幕 |','|---|---|---|']
for a,b,t in CAPTIONS:lines.append(f'| {a:.2f}s | {b:.2f}s | {t} |')
lines+=['\n## 场景与继承关系\n','所有时间均以成片为零点。转场在每段最后 33% 时间内连续进行，并在以下音乐瞬态锚点完成；不是以锚点为硬切点。\n','| 时间段 | 叙事 | 保留元素 → 几何重组 → 下一空间 |','|---|---|---|']
relations=[
'金色光核展开为窗框、书桌和尘埃；纸页沿中轴折起，桌面拉长成道路，桌腿和窗棂伸高成为城市支撑。',
'同一张折纸沿道路飞行；窗灯的暖金向红色过渡，纸张重新摊开，显露红色批改字迹，楼体保持原有位置索引并长高。',
'红色笔迹化为路中光线；楼体与窗灯向两侧拉开，窗灯被拉成城市流光，路边竖杆汇成车厢立柱，主纸面拓展成车窗。',
'流动的蓝色车窗收拢为手机屏幕；车窗四框折合为手机边框，孤独的倒影缩入屏幕周围的暗处。',
'「到家了吗？」留在屏幕；蓝色边框变暖、打开成为门框，屏幕的光绕出灯罩弧线，蓝色桌面收成木质地板。',
'门框与台灯的黄铜暖光保持；灯光螺旋展平为钟表圆周，门框分成钟圈刻度，照片表面迁移为旧车票，空椅子从桌腿关系中长出。',
'钟圈拆为镜框，刻度与记忆碎块向下聚集；暖金渐变冷蓝再向青绿转移，车票纸面拓成镜面，同一光线弯折成发亮裂缝。',
'青绿裂缝沿树干分叉，镜片逐块排成向前的路面；树木保留并移动到路旁，地面碎片升起成微光与远山。',
'道路沿原有方向向晨光延伸；青绿色路面逐渐转暖金，枝条留在身后，几种颜色的碎光被牵引向终点。',
'暖金道路、四色粒子与开篇光核呼应；粒子聚成向前的光束，镜头继续推进，最后 1.2 秒随音乐自然收黑。']
a=music['scene_anchors']
for i,(name,rel) in enumerate(zip(CHAPTERS,relations)):lines.append(f'| {a[i]:.4f}–{a[i+1]:.4f}s | {name} | {rel} |')
lines+=['\n## 音乐依据\n',f"原音频时长 {music['source_duration']:.3f}s；裁切起点 {music['crop_start']:.6f}s；使用连续 108 秒，无替换配乐。",f"全曲自相关得到基础拍速估计 {music['estimated_bpm']:.3f} BPM；不是按该值生成等间距鼓点。",'STFT 分析窗 2048，步长 220 / 22050 s（约 9.98 ms）。低频、中频和高频谱通量分别作为底鼓、军鼓与碎拍的近似检测；混音中没有独立鼓轨，因此这些分类是频段瞬态估计。','节拍路径通过动态规划追随真实谱通量峰值；转场锚点吸附到测得的强瞬态。光路厚度、发光强度、字幕分组显现由事件时间戳驱动。','beats.json 保留所有精确时间、强度、原曲时间和能量变化；music_events.csv 方便剪辑软件或其他引擎使用。']
(ROOT/'analysis/创作说明与时间表.md').write_text('\n'.join(lines))
print('Exported captions, music events and continuity notes.')
