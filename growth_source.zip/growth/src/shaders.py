VERT='''#version 330
in vec3 in_vert; in vec3 in_normal;
in vec3 i_pos; in vec3 i_size; in vec3 i_rot; in vec3 i_color; in float i_emit;
uniform mat4 vp; uniform mat4 light_vp;
out vec3 world; out vec3 normal; out vec3 color; out float emission; out vec4 light_pos;
mat3 rotation(vec3 a){
 float x=a.x,y=a.y,z=a.z;
 mat3 rx=mat3(1,0,0,0,cos(x),sin(x),0,-sin(x),cos(x));
 mat3 ry=mat3(cos(y),0,-sin(y),0,1,0,sin(y),0,cos(y));
 mat3 rz=mat3(cos(z),sin(z),0,-sin(z),cos(z),0,0,0,1);
 return rz*ry*rx;
}
void main(){ mat3 r=rotation(i_rot); world=r*(in_vert*i_size)+i_pos; normal=normalize(r*in_normal);color=i_color;emission=i_emit;light_pos=light_vp*vec4(world,1);gl_Position=vp*vec4(world,1); }
'''
FRAG='''#version 330
in vec3 world; in vec3 normal; in vec3 color; in float emission; in vec4 light_pos;
uniform vec3 camera; uniform vec3 key_color; uniform vec3 accent; uniform vec3 local_light; uniform float local_power; uniform float time; uniform sampler2DShadow shadowmap;
out vec4 frag;
float shadow(){ vec3 p=light_pos.xyz/light_pos.w*.5+.5; if(p.x<0||p.x>1||p.y<0||p.y>1||p.z>1)return 1.;
 float s=0.; float b=max(.0025*(1.-dot(normalize(normal),normalize(vec3(-4,9,4)))),.0010);
 for(int x=-1;x<=1;x++)for(int y=-1;y<=1;y++)s+=texture(shadowmap,vec3(p.xy+vec2(x,y)/1536.,p.z-b));return s/9.; }
void main(){
 vec3 n=normalize(normal); vec3 v=normalize(camera-world);vec3 l=normalize(vec3(-4,9,4));vec3 h=normalize(l+v);
 float ndl=max(dot(n,l),0.);float ndh=max(dot(n,h),0.);float fres=pow(1.-max(dot(n,v),0.),5.);
 float sh=shadow();vec3 kd=color;
 vec3 hemi=mix(vec3(.038,.06,.095),vec3(.21,.25,.3),n.y*.5+.5);
 vec3 co=kd*(hemi+key_color*ndl*sh*1.25);
 co+=key_color*pow(ndh,65.)*.24*sh+accent*fres*.12;
 vec3 dl=local_light-world;float r2=dot(dl,dl);float nl=max(dot(n,normalize(dl)),0.);
 co+=kd*accent*(nl+.12)*local_power/(1.+r2*.65);
 co+=color*emission*2.;
 // fine material variation: paper fibre, wood, oxidised metal, never texture swimming.
 float grain=sin(world.x*91.+sin(world.z*62.))*sin(world.y*84.+world.z*73.);
 co*=1.+grain*.018;
 float dist=length(camera-world);float fog=1.-exp(-max(dist-9.,0.)*.027);
 vec3 fogc=vec3(.011,.022,.035)+accent*.013;
 co=mix(co,fogc,min(fog,.86)); frag=vec4(co,1);
}
'''
DEPTH_FRAG='''#version 330
void main(){}
'''
QUAD='''#version 330
in vec2 in_pos;out vec2 uv;void main(){uv=in_pos*.5+.5;gl_Position=vec4(in_pos,0,1);}
'''
SKY='''#version 330
in vec2 uv;out vec4 frag;uniform vec3 accent;uniform vec2 sun;uniform float sun_power;uniform float sun_radius;uniform float time;
void main(){
 vec3 c=mix(vec3(.018,.032,.05),vec3(.003,.007,.014),smoothstep(.1,1.,uv.y));
 vec2 q=(uv-sun)*vec2(1.777,1);float d=length(q);
 c+=accent*sun_power*(.018/(d*d+.024));
 c+=vec3(1.,.72,.35)*sun_power*3.*(1.-smoothstep(sun_radius,sun_radius+.006,d));
 // broad, soft atmospheric rays moving with the light source
 float a=atan(q.y,q.x);float ray=pow(max(.0,sin(a*13.+.1*sin(time*.12))),12.);
 c+=accent*sun_power*.05*ray*exp(-d*3.);
 frag=vec4(c,1);
}
'''
BLUR='''#version 330
in vec2 uv;out vec4 frag;uniform sampler2D source;uniform vec2 step_uv;uniform float threshold;
vec3 getc(vec2 p){vec3 c=texture(source,p).rgb;return c*max(0.,max(max(c.r,c.g),c.b)-threshold)/(max(max(c.r,c.g),c.b)+.001);}
void main(){vec3 c=getc(uv)*.227027;c+=(getc(uv+step_uv*1.384615)+getc(uv-step_uv*1.384615))*.316216;c+=(getc(uv+step_uv*3.230769)+getc(uv-step_uv*3.230769))*.070270;frag=vec4(c,1);}
'''
POST='''#version 330
in vec2 uv;out vec4 frag;uniform sampler2D source;uniform sampler2D bloom;uniform sampler2D depth_map;uniform sampler2D soft_scene;uniform float focus;uniform float time;uniform float fade;
vec3 aces(vec3 x){return clamp((x*(2.51*x+.03))/(x*(2.43*x+.59)+.14),0.,1.);}
float hash(vec2 p){return fract(sin(dot(p,vec2(12.9898,78.233))+time*41.7)*43758.5453);}
void main(){
 vec2 p=uv-.5;float rr=dot(p,p); vec2 sh=p*rr*.0012;
 vec3 c=texture(source,uv).rgb; c.r=texture(source,uv+sh).r;c.b=texture(source,uv-sh).b;
 float zd=texture(depth_map,uv).r*2.-1.;float depth=2.*.08*150./(150.+.08-zd*(150.-.08));
 float coc=clamp(abs(depth-focus)/max(focus,1.)*.65,0.,.65);
 c=mix(c,texture(soft_scene,uv).rgb,coc);
 c+=texture(bloom,uv).rgb*.32;
 c=pow(aces(c*1.20),vec3(1./2.2));
 c*=1.-.38*smoothstep(.15,.7,length(p*vec2(1.,.85)));
 c+=(hash(gl_FragCoord.xy)-.5)*.014;c*=fade;
 if(uv.y<.064||uv.y>.936)c=vec3(.003,.005,.008)*fade;
 frag=vec4(c,1);
}
'''
TEXT_VERT='''#version 330
in vec2 in_pos;out vec2 uv;uniform vec4 rect;
void main(){uv=in_pos*.5+.5;vec2 p=rect.xy+uv*rect.zw;gl_Position=vec4(p*2.-1.,0,1);}
'''
TEXT_FRAG='''#version 330
in vec2 uv;out vec4 frag;uniform sampler2D image;uniform float opacity;uniform float reveal;
void main(){vec4 c=texture(image,vec2(uv.x,1.-uv.y));float a=1.-smoothstep(reveal,reveal+.035,uv.x);frag=vec4(c.rgb,c.a*opacity*a);}
'''
SURFACE_VERT='''#version 330
in vec3 in_vert;in vec2 in_uv;uniform mat4 vp;out vec2 uv;out vec3 world;
void main(){uv=in_uv;world=in_vert;gl_Position=vp*vec4(in_vert,1);}
'''
SURFACE_FRAG='''#version 330
in vec2 uv;in vec3 world;out vec4 frag;uniform sampler2D texa;uniform sampler2D texb;uniform float blend_value;uniform float opacity;uniform vec3 tint;
void main(){vec4 a=texture(texa,vec2(uv.x,1.-uv.y)),b=texture(texb,vec2(uv.x,1.-uv.y));vec4 c=mix(a,b,blend_value);frag=vec4(pow(c.rgb,vec3(2.2))*tint,c.a*opacity);}
'''

BEAM_VERT='''#version 330
in vec3 in_vert;in vec2 in_uv;uniform mat4 vp;out vec2 uv;
void main(){uv=in_uv;gl_Position=vp*vec4(in_vert,1);}
'''
BEAM_FRAG='''#version 330
in vec2 uv;out vec4 frag;uniform vec3 color;uniform float power;
void main(){float edge=pow(max(0.,sin(uv.x*3.1415926)),1.8);float along=sin(uv.y*3.1415926)*.12+.025;frag=vec4(color*1.8,edge*along*power);}
'''
