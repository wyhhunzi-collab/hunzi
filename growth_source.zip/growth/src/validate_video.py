"""Decode every final frame; report technical integrity and measurable continuity."""
import os,sys,json,subprocess,hashlib
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'.vendor'))
import numpy as np
from scipy import signal
path=Path(sys.argv[1] if len(sys.argv)>1 else ROOT/'output/成长_1080p.mp4').resolve()
probe=json.loads(subprocess.check_output(['ffprobe','-v','error','-show_streams','-show_format','-of','json',str(path)]))
v=next(x for x in probe['streams'] if x['codec_type']=='video');a=next(x for x in probe['streams'] if x['codec_type']=='audio')
assert v['codec_name']=='h264' and a['codec_name']=='aac'
assert (v['width'],v['height'])==(1920,1080)
assert v['r_frame_rate']=='30/1'
assert abs(float(v['duration'])-108)<1/30 and abs(float(a['duration'])-108)<1/30
assert abs(float(v.get('start_time',0))-float(a.get('start_time',0)))<1/30
cmd=['ffmpeg','-v','error','-threads','2','-i',str(path),'-map','0:v:0','-vf','crop=1920:940:0:70,scale=160:80','-pix_fmt','rgb24','-f','rawvideo','pipe:1']
p=subprocess.Popen(cmd,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
framebytes=160*80*3;frames=[]
while True:
 buf=p.stdout.read(framebytes)
 if not buf:break
 assert len(buf)==framebytes,'Truncated decoded frame'
 frames.append(np.frombuffer(buf,np.uint8).reshape(80,160,3).astype(np.float32)/255)
err=p.stderr.read().decode();code=p.wait();assert code==0 and not err,(code,err)
f=np.stack(frames);assert len(f)==3240,len(f)
means=f.mean(axis=(1,2,3));diff=np.abs(np.diff(f,axis=0)).mean(axis=(1,2,3));times=np.arange(len(f))/30
unexpected=np.where((means<.004)&(times>1.8)&(times<106.8))[0]
assert len(unexpected)==0,unexpected
identical=np.where(diff==0)[0]
body_identical=identical[((identical/30)>1.8)&((identical/30)<106.8)]
assert len(body_identical)==0,body_identical
# Evaluate whole decoded image changes rather than counting a generated PID as validation.
spikes=np.argsort(diff)[-12:][::-1]
checks=[]
for t in range(2,102,5):
 changes=np.abs(f[(t+5)*30]-f[t*30]).mean();checks.append({'from':t,'to':t+5,'mean_pixel_change':float(changes)})
assert min(c['mean_pixel_change'] for c in checks)>.001,'Unexplained five-second stillness'
# Check delivered audio timing against the crop used for onset analysis.
raw=subprocess.check_output(['ffmpeg','-v','error','-threads','1','-i',str(path),'-map','0:a:0','-t','10','-ac','1','-ar','22050','-f','f32le','pipe:1'])
rendered=np.frombuffer(raw,np.float32)
from scipy.io import wavfile
sr,src=wavfile.read(ROOT/'analysis/music.wav');src=src.astype(np.float32)/32768
music=json.loads((ROOT/'analysis/beats.json').read_text());offset=round(music['crop_start']*sr)
ref=src[offset:offset+len(rendered)]
# Use seconds 2–8, avoiding the intentional fade-in. Correlation tolerates loudness normalisation.
x=ref[2*sr:8*sr];y=rendered[2*sr:8*sr]
cc=signal.correlate(y,x,method='fft');lags=signal.correlation_lags(len(y),len(x));mask=abs(lags)<int(.1*sr);lag=int(lags[mask][np.argmax(cc[mask])]);corr=float(np.corrcoef(x[max(0,-lag):min(len(x),len(x)-lag)],y[max(0,lag):min(len(y),len(y)+lag)])[0,1])
assert abs(lag/sr)<1/30,(lag/sr,corr)
report={'file':path.name,'size_bytes':path.stat().st_size,'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'resolution':[1920,1080],'fps':30,'decoded_frames':len(f),'duration':float(probe['format']['duration']),'video_codec':v['codec_name'],'audio_codec':a['codec_name'],'audio_sample_rate':int(a['sample_rate']),'video_start':v.get('start_time'),'audio_start':a.get('start_time'),'full_decode_errors':err,'unexpected_black_frames':len(unexpected),'identical_adjacent_frame_pairs':len(identical),'identical_adjacent_frame_pairs_outside_intentional_fades':len(body_identical),'maximum_adjacent_frame_mean_pixel_change':float(diff.max()),'largest_change_times':[{'time':round(float((ix+1)/30),4),'change':float(diff[ix])} for ix in spikes],'five_second_change_checks':checks,'source_audio_alignment_error_seconds':lag/sr,'source_audio_correlation':corr,'interpretation':'No unintentional black frames or identical adjacent frames outside the intentional opening / ending fades. Numerical frame differences and boundary invariants are supporting evidence; contact sheets provide the visual review. Opening and ending fades are intentional.','passed':True}
(ROOT/'analysis/video_validation.json').write_text(json.dumps(report,ensure_ascii=False,indent=2));print(json.dumps(report,ensure_ascii=False,indent=2))
