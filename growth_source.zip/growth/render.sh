#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
export PYTHONPATH="$PWD/.vendor${PYTHONPATH:+:$PYTHONPATH}"
export LP_NUM_THREADS="${LP_NUM_THREADS:-5}"
export OPENBLAS_NUM_THREADS=1
export MESA_SHADER_CACHE_DIR="${MESA_SHADER_CACHE_DIR:-/tmp/growth-mesa-cache}"
mkdir -p analysis output assets preview
if [[ ! -f analysis/music.wav ]]; then
  ffmpeg -y -v warning -i assets/source_music.mp3 -ar 22050 -ac 1 analysis/music.wav
fi
python src/analyze_music.py
python src/export_delivery.py
python src/render.py --render --width 1920 --height 1080 --fps 30 --output growth_silent.mp4
ffmpeg -y -v warning -ss 0.4290249433106576 -i assets/source_music.mp3 -map 0:a:0 -vn -t 108 -af 'afade=t=in:st=0:d=0.35,afade=t=out:st=104.8:d=3.2,loudnorm=I=-16:TP=-1.5:LRA=11' -ar 48000 -c:a aac -b:a 256k assets/soundtrack.m4a
ffmpeg -y -v warning -i output/growth_silent.mp4 -i assets/soundtrack.m4a -map 0:v:0 -map 1:a:0 -c:v copy -c:a copy -t 108 -metadata title='成长' -metadata comment='Code-generated continuous 3D film, 108 seconds' -movflags +faststart 'output/成长_1080p.mp4'
ffmpeg -v error -i 'output/成长_1080p.mp4' -f null -
